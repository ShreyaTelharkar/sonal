package com.cg.eb.except;

public class BillException extends Exception {

	public BillException() {
		// TODO Auto-generated constructor stub
	}

	public BillException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BillException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BillException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BillException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
