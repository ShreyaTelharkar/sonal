package com.cg.eb.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.cg.eb.dto.Consumers;
import com.cg.eb.except.BillException;
import com.cg.eb.service.BillServiceImpl;
import com.cg.eb.service.IBillService;


/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		RequestDispatcher view = null;
		IBillService service = new BillServiceImpl();
		
		// Initial setting the session parameter to false
		// action to fetch movie names available			
			
			
			if(action.equalsIgnoreCase("showList"))
			{
				ArrayList<Consumers> consumerNames;
				try {
					
					
					consumerNames = service.getConsumerNames();
					request.setAttribute("consumerNames", consumerNames);
					
					System.out.println("Action"+action);
					
					for (Consumers consumers : consumerNames) {
						System.out.println(consumers);
					}
					
					view = request.getRequestDispatcher("Show_ConsumerList.jsp");
					view.forward(request, response);
				} catch (BillException e) {
					// TODO Auto-generated catch block
					request.setAttribute("errMsg", e.getMessage());
					view = getServletContext().getRequestDispatcher("error.jsp");
					view.forward(request, response);
				}
				
			}
			
			else if(action.equalsIgnoreCase("showSearchCustomer"))
			{
				view = request.getRequestDispatcher("Search_Consumer.jsp");
				view.forward(request, response);
			}
			
			
			else if(action.equalsIgnoreCase("Search"))
			{
				ArrayList<Consumers> consumerRes;
				try {
					String consumer_num = request.getParameter("consumerId");
					Long consumerNo = Long.parseLong(consumer_num);
					
					System.out.println("consumerNo"+consumerNo);
					
					consumerRes = service.searchConsumer(consumerNo);
					request.setAttribute("consumerRes", consumerRes);
					for (Consumers consumers : consumerRes) {
						System.out.println(consumers);
					}
					
					view = request.getRequestDispatcher("Show_Consumer.jsp");
					view.forward(request, response);
				} catch (BillException e) {
					// TODO Auto-generated catch block
					request.setAttribute("errMsg", e.getMessage());
					view = getServletContext().getRequestDispatcher("error.jsp");
					view.forward(request, response);
				}
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
			
	}

}
