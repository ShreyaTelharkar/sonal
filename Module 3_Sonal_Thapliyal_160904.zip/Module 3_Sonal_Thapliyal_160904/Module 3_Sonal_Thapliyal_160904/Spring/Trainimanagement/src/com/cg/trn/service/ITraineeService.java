package com.cg.trn.service;

import com.cg.trn.bean.Trainee;

public interface ITraineeService {
	public Trainee addTrainee(Trainee trainee);


}
