package com.cg.trn.repo;

import com.cg.trn.bean.Trainee;

public interface ITraineeRepo {
	
	public Trainee addTrainee(Trainee trainee);

}
